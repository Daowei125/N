# Naive Bayes Classifer 朴素贝叶斯分类器

**朴素贝叶斯分类器**(Naive Bayes Classifier,或 NBC)，是依据朴素贝叶斯进行分类的一种条件概率分类器。
详见**朴素贝叶斯**。



